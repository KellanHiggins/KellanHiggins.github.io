﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace BuildingCrafter
{
	public class BCJsonExporterImporterMenu
	{
		[MenuItem("CONTEXT/BuildingBlueprint/Export to JSON")]
		private static void ExportToJson(MenuCommand command)
		{
			BuildingBlueprint bp = (BuildingBlueprint)command.context;

			string path = EditorUtility.SaveFilePanel("Save Blueprint to JSON", Application.dataPath, bp.name, "txt");
			BCJsonExporterImporter.ExportJsonFile(bp, path);
		}

		[MenuItem("CONTEXT/BuildingBlueprint/Import from JSON")]
		private static void ImportJson(MenuCommand command)
		{
			string path = EditorUtility.OpenFilePanel("Load Blueprint from JSON (WILL OVERWRITE CURRENT BLUEPRINT)", Application.dataPath, "txt");

			BuildingBpSerialized newBp = BCJsonExporterImporter.ImportJsonFile(path);

			BuildingBlueprint[] bluePrints = GameObject.FindObjectsOfType<BuildingBlueprint>();
			int index = -1;

			for(int i = 0; i < bluePrints.Length; i++)
			{
				if(bluePrints[i] == (BuildingBlueprint)command.context)
				{
					index = i;
					break;
				}
			}

			if(index > -1)
			{
				newBp.WriteToBp(ref bluePrints[index]);
			}
		}
	}
}